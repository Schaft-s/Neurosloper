import json,os
from pathlib import Path
from mcp.server.fastmcp import FastMCP
from policy import check
server=FastMCP("po-delu")
job=json.loads(Path(os.environ["EDITOR_INPUT"]).read_text())
blocks={b["id"]:b for b in job["blocks"]}

@server.tool()
def read_blocks(start:int=0,count:int=8)->dict:
    """Read consecutive source blocks and their editing permissions, max eight at once."""
    items=list(blocks.values())[max(0,start):max(0,start)+max(1,min(count,8))]
    return {"total":len(blocks),"blocks":[{k:b[k] for k in ("id","label","text","edit")} for b in items if b.get("editorial",True)],"visited":[b["id"] for b in items]}

@server.tool()
def locate_finding(block_id:str,quote:str,pattern:str,effect:str,normal_explanation:str,
                   decision:str="flag",occurrence:int=1)->dict:
    """Anchor a diagnosis to an exact phrase. A plausible unresolved alternative requires uncertain."""
    block=blocks.get(block_id)
    if not block or not block.get("editorial",True) or not quote.strip() or not all(s.strip() for s in [pattern,effect,normal_explanation]):
        return {"accepted":False,"error":"Нужны цитата и основание"}
    if decision not in ("flag","uncertain") or occurrence<1:
        return {"accepted":False,"error":"Проверьте вердикт и номер вхождения"}
    cursor=-1
    for _ in range(occurrence):
        cursor=block["text"].find(quote,cursor+1)
        if cursor<0:return {"accepted":False,"error":"Цитата не найдена"}
    return {"accepted":True,"block_id":block_id,"quote":quote,"start":cursor,"end":cursor+len(quote),
            "pattern":pattern,"effect":effect,"normal":normal_explanation,"decision":decision}

@server.tool()
def check_patch(block_id:str,before:str,after:str,reason:str)->dict:
    """Check an exact whole-block replacement. Empty after means deletion. A risk requires revision."""
    b=blocks.get(block_id)
    error="Исходник не совпадает" if not b or b["text"]!=before else check(b,after,job["length"],job["terms"])
    source=Path(os.environ["EDITOR_INPUT"]).with_name("source.pptx")
    if not error and source.exists():
        from formats import export
        try:
            export("source.pptx",source.read_bytes(),job["blocks"],{block_id:after},strict=True)
        except Exception:
            error="Рендер не подтвердил размещение текста в исходной фигуре"
    selection=job.get("selected",{}).get(block_id)
    if not error and selection:
        # Rewrites must preserve the exact prefix/suffix around the approved finding.
        import re
        cursor=0
        parts=[]
        for span in sorted(selection,key=lambda f:f["start"]):
            parts.extend([re.escape(before[cursor:span["start"]]),".*?"])
            cursor=span["end"]
        parts.append(re.escape(before[cursor:]))
        if not re.fullmatch("".join(parts),after,flags=re.S):
            error="Замена затронула текст вне выбранной цитаты"
    if not reason.strip():
        error="Нужно объяснение"
    return {"accepted":not error,"reason":error or reason,"block_id":block_id}

if __name__=="__main__":
    server.run(transport="stdio")
