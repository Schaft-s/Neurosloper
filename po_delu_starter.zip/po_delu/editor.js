const form = document.querySelector("form");
const statusBox = document.querySelector("#status");
const result = document.querySelector("#result");
let active = null;
let revision = 0;

function element(tag, text = "") {
  const node = document.createElement(tag);
  node.textContent = text;
  return node;
}

function button(label, action) {
  const node = element("button", label);
  node.type = "button";
  node.onclick = async () => {
    const requestRevision = revision;
    node.disabled = true;
    try {
      await action();
    } catch (error) {
      if (requestRevision === revision) statusBox.textContent = error.message;
    } finally {
      node.disabled = false;
    }
  };
  return node;
}

function reset() {
  revision++;
  active = null;
  result.replaceChildren();
  statusBox.textContent = "";
}

function checked(kind) {
  return [...result.querySelectorAll("." + kind + ":checked")].map(node => node.value);
}

async function request(url, payload) {
  const response = await fetch(url, {
    method: "POST",
    headers: {"Content-Type": "application/json"},
    body: JSON.stringify(payload)
  });
  if (!response.ok) throw Error((await response.json()).detail);
  return response;
}

function download(blob, filename) {
  const url = URL.createObjectURL(blob);
  const anchor = element("a");
  anchor.href = url;
  anchor.download = filename;
  anchor.click();
  setTimeout(() => URL.revokeObjectURL(url), 10000);
}

function selectLabel(kind, id, title, enabled = true) {
  const label = element("label", " " + title);
  const box = element("input");
  box.type = "checkbox";
  box.className = kind;
  box.value = id;
  box.disabled = !enabled;
  label.prepend(box);
  return label;
}

function findingCard(job, finding) {
  const block = job.blocks[Number(finding.block_id)];
  const card = element("article");
  const confirmed = finding.decision === "flag";
  const title = block.label + (confirmed ? " · Найдена формулировка" : " · Нужен контекст");
  const chars = Array.from(block.text);
  const quote = element("p");
  quote.append(
    document.createTextNode(chars.slice(Math.max(0, finding.start - 70), finding.start).join("")),
    element("mark", finding.quote),
    document.createTextNode(chars.slice(finding.end, finding.end + 70).join(""))
  );
  card.append(selectLabel("finding", finding.id, title, confirmed && block.edit),
    quote, element("b", finding.pattern), element("p", finding.effect), element("small", finding.normal));
  return card;
}

function reportLinks(job) {
  const kinds = [["docx", "Скачать отчёт"]];
  if ([".pdf", ".pptx"].includes(job.ext)) kinds.push(["pdf", "Замечания на страницах PDF"]);
  for (const [kind, title] of kinds) {
    const link = element("a", title);
    link.href = "/report/" + job.token + "/" + kind;
    link.download = "findings." + kind;
    link.style.marginRight = "16px";
    result.append(link);
  }
  result.append(button("JSON", () => {
    const findings = job.findings.map(f => ({...f, location: job.blocks[Number(f.block_id)].label}));
    const report = {file: job.name, backend: job.backend, blocks_read: job.seen, total: job.total, findings};
    download(new Blob([JSON.stringify(report, null, 2)], {type: "application/json"}), "findings.json");
  }));
}

function preview(job) {
  const card = element("article");
  const label = element("label", "Страница или слайд");
  const number = element("input");
  number.type = "number";
  number.min = 1;
  number.value = 1;
  label.append(number);
  card.append(label);
  const image = element("img");
  image.style.maxWidth = "100%";
  for (const [title, modified] of [["Посмотреть оригинал", false], ["Посмотреть правки", true]]) {
    card.append(button(title, async () => {
      const ids = modified ? checked("patch") : [];
      const response = await request("/preview/" + job.token + "/" + (Number(number.value) - 1), {ids});
      const url = URL.createObjectURL(await response.blob());
      image.onload = () => URL.revokeObjectURL(url);
      image.src = url;
      image.alt = "Предпросмотр страницы " + number.value;
    }));
  }
  card.append(image);
  return card;
}

function show(job, rewritten) {
  active = job;
  result.replaceChildren();
  statusBox.textContent = job.backend + " · Посещено " + job.seen + "/" + job.total +
    " блоков · Доступно для правки: " + job.editable + " · " + job.summary;
  result.append(element("h2", "Замечания"));
  reportLinks(job);
  if (!job.findings.length) result.append(element("p", "В просмотренном материале замечаний нет."));
  for (const finding of job.findings) result.append(findingCard(job, finding));

  if (job.findings.some(f => f.decision === "flag" && job.blocks[Number(f.block_id)].edit)) {
    result.append(button("Предложить замены для выбранных", async () => {
      const seq = revision;
      const response = await request("/rewrite/" + job.token, {
        ids: checked("finding"), style: form.elements.style.value, length: form.elements.length.value
      });
      const updated = await response.json();
      if (seq === revision) show(updated, true);
    }));
  }
  if (rewritten) {
    result.append(element("h2", "Предлагаемые замены"), element("p",job.rewrite_summary || ""));
    if (!job.changes.length) result.append(element("p", "Подходящей замены нет. Замечания доступны выше."));
    for (const change of job.changes) {
      const block = job.blocks[Number(change.id)];
      const card = element("article");
      card.append(selectLabel("patch", change.id, block.label), element("del", block.text),
        element("ins", change.after || "(убрать)"), element("p", change.reason));
      result.append(card);
    }
    const options = [["native", "Скачать с выбранными правками"], ["text", "Скачать чистый текст"]];
    if (job.ext === ".pdf") options.push(["annotate", "PDF с комментариями к заменам"]);
    for (const [mode, title] of options) result.append(button(title, async () => {
      const response = await request("/export/" + job.token, {ids: checked("patch"), mode});
      download(await response.blob(), response.headers.get("Content-Disposition").split('"')[1]);
    }));
  }
  if ([".pdf", ".pptx"].includes(job.ext)) result.append(preview(job));
  const trace = element("details");
  trace.append(element("summary", "Ход проверки MCP"), element("pre", JSON.stringify(job.trace, null, 2)));
  result.append(trace);
}

form.oninput = event => {
  if (active && ["style", "length"].includes(event.target.name)) {
    revision++;
    show({...active, changes: []}, false);
  } else reset();
};
form.elements.file.onchange = () => {
  if (form.elements.file.files[0]?.name.toLowerCase().endsWith(".pptx")) form.elements.length.value = "fit";
  reset();
};
document.querySelector("#example").onclick = () => {
  reset();
  form.elements.file.value = "";
  form.elements.text.value = "В рамках мероприятия будет осуществляться проведение демонстрации станка.";
};
form.onsubmit = async event => {
  event.preventDefault();
  reset();
  const seq = revision;
  const payload = new FormData(form);
  if (!form.elements.file.files.length) payload.delete("file");
  statusBox.textContent = "Идёт проверка…";
  try {
    const response = await fetch("/review", {method: "POST", body: payload});
    const job = await response.json();
    if (seq !== revision) return;
    if (!response.ok) throw Error(job.detail);
    show(job, false);
  } catch (error) {
    if (seq === revision) statusBox.textContent = error.message;
  }
};
