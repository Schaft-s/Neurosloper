"""Private-chat Telegram long polling. No external send until run by the owner."""
import asyncio,os,time
from pathlib import Path
import httpx
from engine import analyze,finish,rewrite
from policy import STYLES,LENGTHS
from formats import LIMIT

class Bot:
    def __init__(self,token,client):
        self.url="https://api.telegram.org/bot"+token+"/"
        self.files="https://api.telegram.org/file/bot"+token+"/"
        self.client=client
        self.sessions={}
    async def api(self,method,**kw):
        response=await self.client.post(self.url+method,**kw)
        response.raise_for_status()
        body=response.json()
        if not body["ok"]:raise ValueError("Telegram не принял запрос")
        return body["result"]
    async def handle(self,m):
        if m["chat"]["type"]!="private":return
        chat=m["chat"]["id"]
        now=time.monotonic()
        for old in list(self.sessions):
            if now-self.sessions[old].get("touched",now)>1800:self.sessions.pop(old)
        if chat not in self.sessions and len(self.sessions)>=32:
            self.sessions.pop(min(self.sessions,key=lambda c:self.sessions[c]["touched"]))
        s=self.sessions.setdefault(chat,dict(style="voice",length="short",terms="",context=""))
        s["touched"]=now
        async def say(text):
            return await self.api("sendMessage",json={"chat_id":chat,"text":text})
        text=m.get("text","")
        command,_,arg=text.partition(" ")
        if command in ("/start","/help"):
            await say("Пришлите текст или файл TXT, MD, DOCX, PPTX, PDF. /style voice|formal|neutral|casual · /length short|near|free|fit · /terms термины через запятую · /context цель · /finding 1 · /report · /rewrite 1,2 · /show 1 · /save 1,2 · /txt all · /clear")
            return
        if command=="/clear":
            self.sessions.pop(chat,None);await say("Черновик удалён.");return
        if command in ("/style","/length","/terms","/context"):
            if command=="/style" and arg not in STYLES or command=="/length" and arg not in LENGTHS:
                await say("Варианты: "+", ".join(STYLES if command=="/style" else LENGTHS));return
            s[command[1:]]=arg
            if s.get("job") and command in ("/style","/length"):
                s["job"].update({command[1:]:arg,"changes":[]})
                await say("Настройка применится к следующей замене. Найденные фрагменты сохранены.");return
            s.pop("job",None);s.pop("data",None)
            await say("Настройка сохранена. Пришлите материал для проверки.");return
        if command in ("/finding","/rewrite","/report","/marked"):
            j=s.get("job")
            if not j:await say("Сначала пришлите материал.");return
            fs=j["findings"]
            if command in ("/report","/marked"):
                from report import diagnostic_report,marked_pages
                name,raw=diagnostic_report(j) if command=="/report" else await asyncio.to_thread(marked_pages,j,s["data"])
                await self.api("sendDocument",data={"chat_id":str(chat)},files={"document":(name,raw)});return
            nums=[int(n) for n in arg.split(",") if n.strip()]
            if not nums or any(n<1 or n>len(fs) for n in nums):raise ValueError("Укажите номер находки")
            if command=="/finding":
                f=fs[nums[0]-1];await say((j["blocks"][int(f["block_id"])]["label"]+" · "+f["decision"]+"\n«"+f["quote"]+"»\n"+f["pattern"]+"\n"+f["effect"]+"\n"+f["normal"])[:4000]);return
            s["job"]=await rewrite(j,s["data"],[fs[n-1]["id"] for n in nums])
            await say(f'Предложено замен: {len(s["job"]["changes"])}. /show 1 — посмотреть. /save 1,2 или /save all — выгрузить. Для сложного PDF: /annotate all или /txt all.')
            if s["job"]["changes"]:await self.handle({"chat":m["chat"],"text":"/show 1"})
            return
        if command in ("/save","/txt","/annotate","/show"):
            j=s.get("job")
            if not j:await say("Сначала пришлите материал.");return
            changes=j["changes"]
            if command=="/show":
                n=int(arg)
                if not 1<=n<=len(changes):raise ValueError("Неизвестный номер")
                c=changes[n-1];b=j["blocks"][int(c["id"])]
                await say((b["label"]+"\nБыло: "+b["text"]+"\nСтало: "+c["after"]+"\n"+c["reason"])[:4000]);return
            nums=range(1,len(changes)+1) if arg=="all" else [int(x) for x in arg.split(",") if x.strip()]
            if any(n<1 or n>len(changes) for n in nums):raise ValueError("Неизвестный номер")
            ids=[changes[n-1]["id"] for n in nums]
            name,data=await asyncio.to_thread(finish,j,s["data"],ids,{"/txt":"text","/annotate":"annotate"}.get(command,"native"))
            await self.api("sendDocument",data={"chat_id":str(chat)},files={"document":(name,data)});return
        if command.startswith("/"):await say("Список команд: /help");return
        if "document" in m:
            d=m["document"]
            if d.get("file_size",0)>LIMIT:raise ValueError("Лимит файла 10 МБ")
            meta=await self.api("getFile",json={"file_id":d["file_id"]})
            r=await self.client.get(self.files+meta["file_path"]);r.raise_for_status()
            name,data=Path(d.get("file_name","document")).name,r.content
        elif text:
            name,data="draft.txt",text.encode()
        else:await say("Пришлите текст или файл.");return
        j=await analyze(name,data,**{k:s[k] for k in ("style","length","terms","context")})
        s.update(job=j,data=data)
        await say(f'{j["backend"]}. Прочитано {j["seen"]}/{j["total"]}. Замечаний: {len(j["findings"])}. '+j["summary"][:700]+"\n/finding 1 — цитата и основание; /report — отчёт DOCX; /marked — разметка страниц PDF/PPTX; /rewrite 1,2 — предложить замены.")
        if j["findings"]:await self.handle({"chat":m["chat"],"text":"/finding 1"})

async def main():
    async with httpx.AsyncClient(timeout=65) as client:
        bot=Bot(os.environ["TELEGRAM_BOT_TOKEN"],client);offset=0
        while True:
            try:
                updates=await bot.api("getUpdates",json={"offset":offset,"timeout":30})
            except httpx.HTTPError:
                await asyncio.sleep(3);continue
            for u in updates:
                if "message" in u:
                    try:await bot.handle(u["message"])
                    except Exception as e:
                        message=str(e) if isinstance(e,ValueError) else "Не удалось обработать запрос"
                        await bot.api("sendMessage",json={"chat_id":u["message"]["chat"]["id"],"text":message[:1000]})
                offset=u["update_id"]+1

if __name__=="__main__":asyncio.run(main())
