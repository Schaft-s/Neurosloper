import asyncio,secrets,time
from pathlib import Path
from fastapi import FastAPI,UploadFile,File,Form,HTTPException
from fastapi.responses import HTMLResponse,Response
from pydantic import BaseModel
from engine import analyze,finish
from formats import LIMIT

app=FastAPI(title="По делу")
jobs={}
gate=asyncio.Semaphore(2)
class Selection(BaseModel):
    ids:list[str]
    mode:str="native"
    style:str|None=None
    length:str|None=None

@app.get("/",response_class=HTMLResponse)
async def home():
    return Path(__file__).with_name("index.html").read_text()

@app.post("/review")
async def review(text:str=Form(""),file:UploadFile|None=File(None),style:str=Form("voice"),
                 length:str=Form("short"),terms:str=Form(""),context:str=Form("")):
    data=await file.read(LIMIT+1) if file else text.encode()
    name=Path(file.filename or "file").name if file else "draft.txt"
    try:
        async with gate:
            job=await analyze(name,data,style,length,terms,context)
    except Exception as e:
        raise HTTPException(422,str(e) if isinstance(e,ValueError) else "Не удалось разобрать файл или получить ответ модели")
    for token in list(jobs):
        if jobs[token][0]<time.monotonic()-1800:jobs.pop(token)
    while len(jobs)>=16:jobs.pop(next(iter(jobs)))
    token=secrets.token_urlsafe(32)
    jobs[token]=(time.monotonic(),job,data)
    return dict(token=token,**job)

@app.post("/export/{token}")
async def download(token:str,selection:Selection):
    saved=jobs.get(token)
    if not saved or time.monotonic()-saved[0]>1800:
        raise HTTPException(404,"Сессия истекла")
    try:
        name,data=await asyncio.to_thread(finish,saved[1],saved[2],selection.ids,selection.mode)
    except (ValueError,RuntimeError) as e:
        raise HTTPException(422,str(e))
    return Response(data,media_type="application/octet-stream",headers={"Content-Disposition":f'attachment; filename="{name}"'})

@app.post("/preview/{token}/{page}")
async def preview(token:str,page:int,selection:Selection):
    from formats import render
    import pymupdf
    saved=jobs.get(token)
    if not saved or time.monotonic()-saved[0]>1800: raise HTTPException(404,"Сессия истекла")
    if saved[1]["ext"] not in {".pptx",".pdf"}:raise HTTPException(422,"Предпросмотр только для PDF и PPTX")
    def image():
        name,data=finish(saved[1],saved[2],selection.ids,selection.mode)
        if name.endswith(".pptx"):data=render(data)
        with pymupdf.open(stream=data,filetype="pdf") as doc:
            if not 0<=page<len(doc):raise ValueError("Нет такой страницы")
            return doc[page].get_pixmap(matrix=pymupdf.Matrix(1,1)).tobytes("png")
    try:return Response(await asyncio.to_thread(image),media_type="image/png")
    except Exception as e:raise HTTPException(422,str(e) if isinstance(e,ValueError) else "Ошибка рендера")

@app.post("/rewrite/{token}")
async def suggestions(token:str,selection:Selection):
    from engine import rewrite
    saved=jobs.get(token)
    if not saved or time.monotonic()-saved[0]>1800:raise HTTPException(404,"Сессия истекла")
    try:
        async with gate:
            settings=dict(saved[1])
            if selection.style:settings["style"]=selection.style
            if selection.length:settings["length"]=selection.length
            j=await rewrite(settings,saved[2],selection.ids)
    except Exception as e:
        raise HTTPException(422,str(e) if isinstance(e,ValueError) else "Не удалось получить замену")
    new=secrets.token_urlsafe(32)
    while len(jobs)>=16:jobs.pop(next(iter(jobs)))
    jobs[new]=(time.monotonic(),j,saved[2])
    return dict(token=new,**j)

@app.get("/report/{token}/{kind}")
async def report(token:str,kind:str):
    from report import diagnostic_report,marked_pages
    saved=jobs.get(token)
    if not saved or time.monotonic()-saved[0]>1800:raise HTTPException(404,"Сессия истекла")
    try:
        if kind=="docx":name,data=diagnostic_report(saved[1])
        elif kind=="pdf":name,data=await asyncio.to_thread(marked_pages,saved[1],saved[2])
        else:raise ValueError("Неизвестный формат отчёта")
    except ValueError as e:raise HTTPException(422,str(e))
    return Response(data,media_type="application/octet-stream",headers={"Content-Disposition":f'attachment; filename="{name}"'})

@app.get("/editor.js")
async def editor_script():
    return Response(Path(__file__).with_name("editor.js").read_text(),media_type="application/javascript")
