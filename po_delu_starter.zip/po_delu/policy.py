import re
from collections import Counter

STYLES={"voice":"Сохранить голос автора","neutral":"Нейтрально","formal":"Формально","casual":"Разговорно"}
LENGTHS={"free":"Свободная длина","short":"Не длиннее исходного блока","near":"Близко к исходнику (±10%)","fit":"В рамку PPTX; для других файлов — не длиннее"}
ANCHOR=re.compile(r"https?://[^\s)]+|[\w.+-]+@[\w.-]+|\d+(?:[.,:/–-]\d+)*(?:\s?(?:%|₽|кг|мм|МБ|ГБ))?|\b(?:не менее|не более|не ранее|не позднее|только если|не|должен|должна|должны|запрещено)\b",re.I)

def check(block,new,length,terms):
    old=block["text"]
    if not block["edit"] or not isinstance(new,str) or new==old:
        return "Недоступная или пустая операция"
    if len(new)>min(16000,len(old)*4+80) or any(ord(c)<32 and c not in "\n\t" for c in new):
        return "Некорректный размер или символ"
    if "\n" in new and "\n" not in old:
        return "Изменена структура абзаца"
    if (length=="short" or length=="fit" and "shape" not in block) and len(new)>len(old):
        return "Превышен предел длины"
    if length=="near" and abs(len(new)-len(old))>max(1,len(old)*.1):
        return "Изменение превышает 10%"
    if Counter(ANCHOR.findall(old.casefold()))!=Counter(ANCHOR.findall(new.casefold())):
        return "Изменены числа, адрес, отрицание или условие"
    if any(old.count(t)!=new.count(t) for t in terms if t):
        return "Изменён защищённый термин"
    return ""
