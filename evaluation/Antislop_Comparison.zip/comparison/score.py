"""Score saved outputs, including a paired document bootstrap. Requires numpy."""
from pathlib import Path
import csv,json,itertools
from collections import Counter
import numpy as np
ROOT=Path(__file__).resolve().parent
def read(name):
    seq=[json.loads(s) for s in (ROOT/(name+".jsonl")).read_text().splitlines() if s.strip()]
    assert len({r["id"] for r in seq})==len(seq)==40,name
    return {r['id']:r for r in seq}

def align(pred,ref,t):
    def fits(p,r):
        a,b=p['start'],p['end']; c,d=r['start'],r['end']
        n=max(0,min(b,d)-max(a,c))
        return n>0 and n/(b-a+d-c-n)>=t
    edges=[[j for j,r in enumerate(ref) if fits(p,r)] for p in pred]
    right={}
    def visit(i,seen):
        for j in edges[i]:
            if j in seen:continue
            seen.add(j)
            if j not in right or visit(right[j],seen):
                right[j]=i
                return True
        return False
    for i in range(len(pred)):visit(i,set())
    return len(right)
def rates(c):
    tp,fp,fn=map(int,c);p=tp/(tp+fp) if tp+fp else 0;r=tp/(tp+fn) if tp+fn else 0
    return dict(tp=tp,fp=fp,fn=fn,P=p,R=r,F1=2*p*r/(p+r) if p+r else 0)
def triple(p,r,t):
    n=align(p,r,t)
    return [n,len(p)-n,len(r)-n]
def f1_tensor(arr):
    tp,fp,fn=np.moveaxis(arr,-1,0);den=2*tp+fp+fn
    return np.divide(2*tp,den,out=np.zeros(den.shape,float),where=den!=0)

def main():
    ref=read('references');inputs=read('inputs');ids=list(inputs)
    tags=['s1','s2','f1','f2']
    groups={}; detail=[]
    for tag in tags:
        rows=read(tag);assert set(rows)==set(ids)
        groups[tag]={}
        for k in ids:
            text=inputs[k]['text'];assert text==ref[k]['text']
            fs=rows[k]['findings'];spans=[]
            for f in fs:
                quote=f['quote'];assert quote and quote in text,(tag,k,quote)
                start=f.get('start',text.index(quote))
                assert text[start:start+len(quote)]==quote
                if text.count(quote)>1 and 'start' not in f:raise ValueError((tag,k,'Repeated quote without offsets',quote))
                spans.append({**f,'start':start,'end':start+len(quote)})
            assert len({(f['start'],f['end']) for f in spans})==len(spans)
            groups[tag][k]=spans
    for g in ['a','b']:groups[g]={k:ref[k]['review_'+g] for k in ids}
    metrics={}; per={}
    for t in [.25,.5,.75,1.]:
        result={}
        for g,h in [*itertools.product(tags,['a','b']),('s1','s2'),('f1','f2'),('a','b')]:
            c=np.array([triple(groups[g][k],groups[h][k],t) for k in ids])
            result[g+'_'+h]=rates(c.sum(axis=0))
            if t==.5:per[g,h]=c
        metrics[str(t)]=result
    effect={}
    rng=np.random.default_rng(27112026)
    weights=rng.multinomial(40,np.ones(40)/40,size=5000)
    for field in ('short','full'):
        tags2=tags[:2] if field=='short' else tags[2:]
        effect[field]=np.mean([f1_tensor(weights@per[g,h]) for g,h in itertools.product(tags2,['a','b'])],axis=0)
    delta=effect['full']-effect['short']
    scores={'n':40,'metrics':metrics,'bootstrap_delta_f1_95':np.quantile(delta,[.025,.975]).tolist(),'rng_seed':27112026,'bootstrap_n':5000,'runs':{}}
    clean=[k for k in ids if not groups['a'][k] and not groups['b'][k]]
    for tag in tags:
        size=[len(groups[tag][k]) for k in ids]
        scores['runs'][tag]=dict(spans=sum(size),flagged_docs=sum(v>0 for v in size),flags_on_consensus_clean=sum(bool(groups[tag][k]) for k in clean),consensus_clean=len(clean))
    for i,k in enumerate(ids):
        d={'id':k,'source':ref[k]['url'],'prompt':inputs[k]['prompt'],'text':inputs[k]['text']}
        for t in tags+['a','b']:d[t]=groups[t][k]
        full=sum(per[t,h][i][0] for t,h in itertools.product(tags[2:],['a','b']))
        short=sum(per[t,h][i][0] for t,h in itertools.product(tags[:2],['a','b']))
        d['difference_in_summed_matches']=int(full-short)
        detail.append(d)
    (ROOT/'scores.json').write_text(json.dumps(scores,indent=2,ensure_ascii=False))
    (ROOT/'documents.jsonl').write_text(''.join(json.dumps(d,ensure_ascii=False)+'\n' for d in detail))
    print(json.dumps({'runs':scores['runs'],'interval':scores['bootstrap_delta_f1_95'],'primary':metrics['0.5']},indent=2))
if __name__=='__main__':main()
