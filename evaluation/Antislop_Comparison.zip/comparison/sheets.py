from pathlib import Path
import json
from openpyxl import Workbook
from openpyxl.styles import Font,PatternFill,Alignment
from openpyxl.utils import get_column_letter
from score import align
p=Path(__file__).resolve().parent
sc=json.loads((p/'scores.json').read_text());docs=[json.loads(l) for l in (p/'documents.jsonl').read_text().splitlines()]
wb=Workbook();s=wb.active;s.title='Сравнение'
s.append(['Условие','Прогон','Рецензент','IoU','Совпали','Лишние к эталону','Пропуски','Precision','Recall','F1'])
names={'s1':'Короткая','s2':'Короткая','f1':'Полный скилл','f2':'Полный скилл','a':'Рецензент A','b':'Рецензент B'}
for t,vals in sc['metrics'].items():
 for pair,m in vals.items():
  g,h=pair.split('_');s.append([names[g],g,h,float(t),m['tp'],m['fp'],m['fn'],m['P'],m['R'],m['F1']])
  for c in s[s.max_row][7:]:c.number_format='0.0%'
d=wb.create_sheet('Документы');d.append(['ID','Запрос','Ответ','Короткая 1','Короткая 2','Скилл 1','Скилл 2','Рецензент A','Рецензент B','Источник'])
f=wb.create_sheet('Фрагменты');f.append(['ID','Условие','Прогон','Точная цитата','Объяснение','Начало','Конец','Совпало с A (IoU≥0,5)','Совпало с B (IoU≥0,5)'])
for doc in docs:
 d.append([doc['id'],doc['prompt'],doc['text'],*[len(doc[tag]) for tag in ('s1','s2','f1','f2','a','b')],doc['source']])
 d.cell(d.max_row,10).hyperlink=doc['source']
 for tag in ('s1','s2','f1','f2','a','b'):
  for hit in doc[tag]:
   f.append([doc['id'],names[tag],tag,hit['quote'],hit['why'],hit['start'],hit['end'],bool(align([hit],doc['a'],.5)),bool(align([hit],doc['b'],.5))])
for sh,w in [(s,[22,13,15,10,15,22,15,16,16,16]),(d,[28,48,85,16,16,16,16,16,16,36]),(f,[28,20,13,65,68,12,12,22,22])]:
 sh.freeze_panes='D2' if sh==f else 'A2';sh.auto_filter.ref=sh.dimensions
 for i,size in enumerate(w,1):sh.column_dimensions[get_column_letter(i)].width=size
 for c in sh[1]:c.fill=PatternFill('solid',fgColor='225344');c.font=Font(color='FFFFFF',bold=True);c.alignment=Alignment(wrap_text=True)
 sh.row_dimensions[1].height=32
 for row in sh.iter_rows(min_row=2):
  if sh!=s:sh.row_dimensions[row[0].row].height=65
  for c in row:
   c.alignment=Alignment(vertical='top',wrap_text=True)
   if c.data_type=='f':c.data_type='s'
wb.save(p/'Antislop_Comparison.xlsx')
