import json,random
from pathlib import Path
from score import align
p=Path(__file__).resolve().parent
out=[];mapping=[];rng=random.Random(2841)
for line in (p/'documents.jsonl').read_text().splitlines():
 d=json.loads(line)
 for tag,twin,opp in [('s1','s2',['f1','f2']),('f1','f2',['s1','s2'])]:
  for f in d[tag]:
   if not align([f],d[twin],.5) or any(align([f],d[t],.5) for t in opp):continue
   out.append(dict(id=d['id'],prompt=d['prompt'],text=d['text'],quote=f['quote'],tag=tag))
rng.shuffle(out)
chosen=[];counts={'s1':0,'f1':0};used=set()
for x in out:
 if counts[x['tag']]>=8 or x['id'] in used:continue
 used.add(x['id']);counts[x['tag']]+=1
 code='X'+str(len(chosen)+1);mapping.append({'key':code,'system':x['tag']})
 chosen.append({'key':code,**{k:x[k] for k in ('prompt','text','quote')}})
for name,data in [('disputes_blind',chosen),('disputes_origin',mapping)]:
 (p/(name+'.jsonl')).write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in data))
print(counts)
