from pathlib import Path
from lxml import etree
import json
base=Path(__file__).parent
rows=[]
for p in sorted(Path('/usr/share/metainfo').glob('*.xml')):
    doc=etree.parse(str(p))
    text='\n\n'.join(' '.join(''.join(n.itertext()).split()) for n in doc.xpath('/component/description/p[@xml:lang="ru"]'))
    if text: rows.append(dict(id='P%02d'%(len(rows)+1),text=text,source=str(p),license=doc.findtext('metadata_license')))
for name,values in [('products_keys',rows),('products_blind',[dict(id=r['id'],text=r['text']) for r in rows])]:
    (base/(name+'.jsonl')).write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in values))
print(len(rows))
