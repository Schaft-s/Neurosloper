import json,random,statistics,re
from collections import Counter
from pathlib import Path
from itertools import product
root=Path(__file__).resolve().parent
def read(name):
    data=[json.loads(l) for l in (root/(name+'.jsonl')).read_text().splitlines()]
    out={r['id']:r for r in data}
    assert len(out)==len(data)
    return out
def spans(text,quotes):
    counts=Counter(quotes)
    out=[]
    for q,n in counts.items():
        found=[m.span() for m in re.finditer(re.escape(q),text)]
        assert q and len(found)==n,(q,n,found)
        out.extend(found)
    return out
def iou(x,y):
    n=max(0,min(x[1],y[1])-max(x[0],y[0]))
    return n/(x[1]-x[0]+y[1]-y[0]-n)
def match(p,r):
    pairs={}
    def visit(i,used):
        for j,q in enumerate(r):
            if j in used or iou(p[i],q)<.5:continue
            used.add(j)
            if j not in pairs or visit(pairs[j],used):
                pairs[j]=i
                return True
        return False
    return sum(visit(i,set()) for i in range(len(p)))
keys=read('keys');products=read('products_keys')
en=[k for k,r in keys.items() if r['kind']=='en_wiki']
ru=set(keys)-set(en)
tags=['old','old2','new','new2']
results={};hits={}
for tag in tags:
    pred=read(tag);pp=read('p_'+tag)
    assert set(pred)==set(keys) and set(pp)==set(products)
    for r in [*pred.values(),*pp.values()]:
        for f in ['flags','uncertain']:spans((keys|products)[r['id']]['text'],r[f])
    h=[]
    for k in en:
        t=keys[k]['text']
        m=spans(t,keys[k]['marks']);p=spans(t,pred[k]['flags'])
        h.append(max((iou(x,y) for x in p for y in m),default=0))
    hits[tag]=h
    counts=[]
    for reviewer in ['p_ref1','p_ref2']:
        ref=read(reviewer);assert set(ref)==set(products)
        tp=np=nr=0
        for k,r in products.items():
            p=spans(r['text'],pp[k]['flags']);g=spans(r['text'],ref[k]['flags'])
            tp+=match(p,g);np+=len(p);nr+=len(g)
        counts.append(dict(matches=tp,pred=np,ref=nr,F1=2*tp/(np+nr)))
    results[tag]=dict(en_hits=[sum(x>0 for x in h),sum(x>=.5 for x in h),sum(x==1 for x in h)],en_flags=sum(len(pred[k]['flags']) for k in en),en_uncertain_docs=sum(bool(pred[k]['uncertain']) for k in en),ru_flags=[k for k in sorted(ru) if pred[k]['flags']],ru_uncertain=[k for k in sorted(ru) if pred[k]['uncertain']],products=counts)
delta=[((c>=.5)+(d>=.5)-(a>=.5)-(b>=.5))/2 for a,b,c,d in zip(*(hits[t] for t in tags))]
rng=random.Random(284);sim=sorted(statistics.mean(rng.choices(delta,k=len(delta))) for _ in range(10000))
results['difference']=[statistics.mean(delta),sim[249],sim[9749]]
results['case_iou']={k:dict(zip(tags,x)) for k,x in zip(en,zip(*(hits[t] for t in tags)))}
(root/'scores.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
print(json.dumps({k:v for k,v in results.items() if k!='case_iou'},ensure_ascii=False,indent=1))
ck=json.loads((root/'contrast_key.json').read_text())
summary={}
for tag in ['old','new']:
    forms={}
    for f in ['c','z']:
        a,b=[read(f'{f}_{tag}{i}') for i in range(2)]
        assert not set(a)&set(b)
        decisions={k:r['decision'] for k,r in (a|b).items()}
        assert set(decisions)=={r['id'] for r in ck}
        forms[f]=decisions
    summary[tag]={f:sum(ans[r['id']]==r['expected'] for r in ck) for f,ans in forms.items()}
    summary[tag]['pairs_both_forms_correct']=sum(all(forms[f][r['id']]==r['expected'] for f in forms for r in ck if r['pair']==i) for i in range(1,9))
    summary[tag]['invariant']=sum(forms['c'][k]==forms['z'][k] for k in forms['c'])
results['contrast']=summary
(root/'scores.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
print(summary)
