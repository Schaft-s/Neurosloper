import json
from pathlib import Path
base=Path(__file__).parent
variants=['Теперь предстоит сопоставить несовпадающие записи.','Ни одну из заявок пока не исключаем.','Эту проверку закончили.','С этого момента выбор за мастером смены.','После этого вся смена стала работать в другой последовательности.','Один график имеет смысл только в сопоставлении со вторым.','Здесь многое определяется обстановкой на месте.','Дальше процесс может пойти по одному из двух путей.']
lookup={r['id']:r['pair'] for r in json.loads((base/'contrast_key.json').read_text())}
for i in range(2):
    rs=[json.loads(l) for l in (base/f'contrast{i}.jsonl').read_text().splitlines()]
    for row in rs: row['target']=variants[lookup[row['id']]-1]
    (base/f'paraphrase{i}.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in reversed(rs)))
