import gettext, hashlib, json, random, re
from collections import defaultdict
from pathlib import Path
from urllib.parse import urljoin
from lxml import html
root=Path(__file__).resolve().parent
def save(name,rows):
    (root/name).write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows))
def norm(x): return ' '.join(x.split())
d=html.parse('/tmp/realset/wiki.html')
records=[json.loads(s) for s in (root.parent/'corpus/wiki_editorial.jsonl').read_text().splitlines()]
lookup={r['source_revision_url']:r for r in records}
groups=defaultdict(list)
for b in d.xpath('//blockquote[.//cite]'):
    url=next((urljoin('https://en.wikipedia.org',u) for u in b.xpath('.//cite//a/@href') if urljoin('https://en.wikipedia.org',u) in lookup),None)
    if not url:continue
    r=lookup.pop(url)
    for e in b.xpath('.//cite'): e.drop_tree()
    marks=[norm(e.text_content()) for e in b.xpath('.//mark')]
    t=norm(b.text_content())
    if not 80<=len(t)<=1600:continue
    spans=[m for m in marks if m and m in t]
    if spans:groups[r['source_label']].append(dict(text=t,marks=spans,source=url,family=r['source_label'],kind='en_wiki'))
rng=random.Random(41542)
for v in groups.values():rng.shuffle(v)
rows=[]
while len(rows)<24 and any(groups.values()):
    for v in groups.values():
        if v and len(rows)<24:rows.append(v.pop())
for pkg in ['git','gimp30','inkscape','blender']:
    path=Path('/usr/share/locale/ru/LC_MESSAGES')/(pkg+'.mo')
    cat=gettext.GNUTranslations(path.open('rb'))._catalog
    pairs=sorted((k,v) for k,v in cat.items() if isinstance(k,str) and k and isinstance(v,str) and 160<=len(v)<=650 and '%' not in v and '<' not in v and v.count('.')>=2 and re.search('[а-я]',v))
    for k,v in rng.sample(pairs,min(len(pairs),5)):
        rows.append(dict(text=v,source=str(path),source_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),msgid=k,kind='ru_ui',family=pkg))
rng.shuffle(rows)
for i,r in enumerate(rows):r['id']=f'D{i+1:02d}'
save('blind.jsonl',[dict(id=r['id'],text=r['text']) for r in rows])
save('keys.jsonl',rows)
from collections import Counter
print(Counter(r['kind'] for r in rows),Counter(r['family'] for r in rows if r['kind']=='ru_ui'))
